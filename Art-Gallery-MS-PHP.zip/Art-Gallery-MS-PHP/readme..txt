Credential for Admin panel :

Username: admin
Password: Test@123

